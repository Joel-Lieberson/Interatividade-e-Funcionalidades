
// main.js — Bootstraps SPA, binds events, and integrates modules
import { Router } from './router.js';
import { Templates } from './templates.js';
import { validateForm, showErrors } from './validation.js';
import { Store } from './storage.js';

// small toast
function toast(msg){
  let t = document.querySelector('.toast');
  if(!t){
    t = document.createElement('div');
    t.className = 'toast';
    document.body.appendChild(t);
  }
  t.textContent = msg;
  t.classList.add('show');
  setTimeout(() => t.classList.remove('show'), 3000);
}

function mount(html){
  const app = document.querySelector('#app');
  if(app){ app.innerHTML = html; }
}

function initCadastroPage(){
  const form = document.querySelector('#form-cadastro');
  if(!form) return;
  // live blur validations
  form.querySelectorAll('.form-control').forEach(input => {
    input.addEventListener('blur', () => {
      const errs = validateForm(form);
      if(errs[input.id]){
        input.classList.add('is-invalid');
      }else{
        input.classList.remove('is-invalid');
      }
    });
  });
  // submit handler
  form.addEventListener('submit', (e) => {
    e.preventDefault();
    const errors = validateForm(form);
    if(Object.keys(errors).length){
      showErrors(form, errors);
      toast('Há inconsistências no formulário. Revise os campos.');
      return;
    }
    const data = Object.fromEntries(new FormData(form).entries());
    Store.add(data);
    location.hash = '#/sucesso';
  });
}

function inicio(){ mount(Templates.inicio()); }
function projetos(){ mount(Templates.projetos()); }
function cadastro(){ mount(Templates.cadastro()); initCadastroPage(); }
function sucesso(){
  const list = Store.all();
  const last = list[list.length-1] || {};
  mount(Templates.sucesso(last.nome || ''));
}

new Router({
  'inicio': inicio,
  'projetos': projetos,
  'cadastro': cadastro,
  'sucesso': sucesso,
  '404': () => mount(Templates.notFound())
});
