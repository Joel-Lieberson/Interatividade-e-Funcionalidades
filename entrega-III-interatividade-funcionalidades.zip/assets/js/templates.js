
// templates.js — JavaScript template system
export const Templates = {
  inicio: () => `
    <section class="hero u-pt-32" aria-labelledby="boasvindas">
      <div>
        <h1 id="boasvindas">Transformando realidades com educação e solidariedade</h1>
        <p>Somos uma organização sem fins lucrativos dedicada a projetos sociais que ampliam oportunidades por meio de educação, cultura e cidadania.</p>
        <p><a class="btn" href="#/projetos" data-route>Ver projetos sociais</a></p>
      </div>
      <figure>
        <picture>
          <source srcset="assets/images/hero.webp" type="image/webp">
          <source srcset="assets/images/hero.png" type="image/png">
          <img src="assets/images/hero.png" width="800" height="520" alt="Voluntários sorrindo em atividade comunitária">
        </picture>
        <figcaption class="note">Nossas ações contam com voluntários de diversas áreas.</figcaption>
      </figure>
    </section>
    <div class="alert alert-info">Plataforma em constante melhoria — confira nossos projetos e participe!</div>
    <section aria-labelledby="contato">
      <h2 id="contato">Contato</h2>
      <div class="row">
        <div class="col-12 col-sm-6 col-lg-4">
          <div class="card"><h3>Endereço</h3><p>Rua Solidária, 123 — Centro, Fortaleza/CE</p></div>
        </div>
        <div class="col-12 col-sm-6 col-lg-4">
          <div class="card"><h3>Telefone</h3><p><a href="tel:+5585999999999">+55 (85) 99999-9999</a></p></div>
        </div>
        <div class="col-12 col-sm-6 col-lg-4">
          <div class="card"><h3>E-mail</h3><p><a href="mailto:contato@institutofuturomelhor.org">contato@institutofuturomelhor.org</a></p></div>
        </div>
      </div>
    </section>
  `,
  projetos: () => `
    <article aria-labelledby="proj-title">
      <header>
        <h1 id="proj-title">Projetos sociais</h1>
        <p class="note">Conheça iniciativas ativas e como você pode apoiar.</p>
      </header>
      <section>
        <h2>Voluntariado</h2>
        <div class="cards">
          <div class="card project-card">
            <img src="assets/images/aula.png" alt="Mentoria de jovens" width="480" height="320">
            <h3 id="mentoria">Mentoria Jovem</h3>
            <div class="meta"><span class="badge">Educação</span><span class="badge">Juventude</span></div>
            <p>Aulas de reforço escolar e orientação de carreira para adolescentes.</p>
          </div>
          <div class="card project-card">
            <img src="assets/images/feira.png" alt="Feira solidária" width="480" height="320">
            <h3 id="feira">Feira Solidária</h3>
            <div class="meta"><span class="badge">Assistência</span><span class="badge">Comunidade</span></div>
            <p>Doação de alimentos e serviços básicos às famílias cadastradas.</p>
          </div>
          <div class="card project-card">
            <img src="assets/images/tec.png" alt="Inclusão digital" width="480" height="320">
            <h3 id="inclusao">Inclusão Digital</h3>
            <div class="meta"><span class="badge">Tecnologia</span><span class="badge">Habilidades</span></div>
            <p>Oficinas de tecnologia para promover habilidades do futuro.</p>
          </div>
        </div>
      </section>
      <section>
        <h2>Como doar</h2>
        <p>Contribua pelo e-mail <a href="mailto:doe@institutofuturomelhor.org">doe@institutofuturomelhor.org</a> ou clique em <a href="#" data-open-modal>Quero doar</a>.</p>
      </section>
    </article>
  `,
  cadastro: () => `
    <article aria-labelledby="cadastro-title">
      <header>
        <h1 id="cadastro-title">Cadastro de voluntários e doadores</h1>
        <p class="note">Campos com * são obrigatórios. Seus dados serão usados apenas para fins institucionais.</p>
      </header>
      <form id="form-cadastro" novalidate>
        <fieldset>
          <legend>Dados Pessoais</legend>
          <label class="required" for="nome">Nome completo</label>
          <input id="nome" name="nome" type="text" placeholder="Seu nome" autocomplete="name" required minlength="3" class="form-control">
          <label class="required" for="email">E-mail</label>
          <input id="email" name="email" type="email" placeholder="seuemail@exemplo.com" autocomplete="email" required class="form-control">
          <label class="required" for="cpf">CPF</label>
          <input id="cpf" name="cpf" type="text" inputmode="numeric" placeholder="000.000.000-00" required pattern="\\d{3}\\.\\d{3}\\.\\d{3}-\\d{2}" aria-describedby="cpf-hint" class="form-control">
          <div id="cpf-hint" class="note">Formato: 000.000.000-00</div>
          <label class="required" for="telefone">Telefone</label>
          <input id="telefone" name="telefone" type="tel" inputmode="tel" placeholder="(00) 00000-0000" required pattern="\\(\\d{2}\\)\\s\\d{4,5}-\\d{4}" aria-describedby="tel-hint" class="form-control">
          <div id="tel-hint" class="note">Aceita 8 ou 9 dígitos no número.</div>
          <label class="required" for="nascimento">Data de Nascimento</label>
          <input id="nascimento" name="nascimento" type="date" required class="form-control">
        </fieldset>
        <fieldset>
          <legend>Endereço</legend>
          <label class="required" for="endereco">Endereço</label>
          <input id="endereco" name="endereco" type="text" placeholder="Rua, número e complemento" required autocomplete="address-line1" class="form-control">
          <label class="required" for="cep">CEP</label>
          <input id="cep" name="cep" type="text" inputmode="numeric" placeholder="00000-000" required pattern="\\d{5}-\\d{3}" aria-describedby="cep-hint" class="form-control">
          <div id="cep-hint" class="note">Formato: 00000-000</div>
          <label class="required" for="cidade">Cidade</label>
          <input id="cidade" name="cidade" type="text" required autocomplete="address-level2" class="form-control">
          <label class="required" for="estado">Estado</label>
          <select id="estado" name="estado" required autocomplete="address-level1" class="form-control">
            <option value="" selected hidden>Selecione</option>
            ${['AC','AL','AP','AM','BA','CE','DF','ES','GO','MA','MT','MS','MG','PA','PB','PR','PE','PI','RJ','RN','RS','RO','RR','SC','SP','SE','TO'].map(uf=>`<option>${uf}</option>`).join('')}
          </select>
        </fieldset>
        <fieldset>
          <legend>Preferências</legend>
          <label for="tipo">Quero me cadastrar como</label>
          <select id="tipo" name="tipo" class="form-control">
            <option>Voluntário(a)</option>
            <option>Doador(a)</option>
            <option>Ambos</option>
          </select>
          <label for="interesses">Áreas de interesse</label>
          <textarea id="interesses" name="interesses" rows="3" class="form-control" placeholder="Conte como gostaria de contribuir"></textarea>
        </fieldset>
        <p>
          <button class="btn" type="submit">Enviar cadastro</button>
          <button class="btn btn-ghost" type="reset">Limpar</button>
        </p>
      </form>
    </article>
  `,
  sucesso: (nome='') => `
    <section class="u-pt-32">
      <div class="card u-center">
        <h2>Obrigado${nome?`, ${nome}`:''}! 🎉</h2>
        <p class="u-mb-16">Seu cadastro foi recebido (simulado) e salvo no seu navegador.</p>
        <p><a class="btn" href="#/inicio" data-route>Voltar ao início</a></p>
      </div>
    </section>
  `,
  notFound: () => `<div class="alert alert-warning">Página não encontrada.</div>`
};
