
// validation.js — Consistency checks for form fields
export const Validators = {
  email(v){ return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v); },
  telefone(v){
    const d = v.replace(/\D/g,'');
    return d.length===10 || d.length===11;
  },
  cep(v){ return /^\d{5}-\d{3}$/.test(v); },
  nascimento(v){
    const d = new Date(v);
    if(isNaN(d)) return false;
    const today = new Date();
    if(d > today) return false;
    const age = today.getFullYear() - d.getFullYear() - ((today.getMonth()<d.getMonth() || (today.getMonth()==d.getMonth() && today.getDate()<d.getDate()))?1:0);
    return age >= 16; // regra de exemplo
  },
  cpf(v){
    const s = v.replace(/\D/g,'');
    if(!/^\d{11}$/.test(s)) return false;
    if(/^(.)\1{10}$/.test(s)) return false; // evita repetidos
    let sum = 0;
    for(let i=0;i<9;i++) sum += parseInt(s[i])*(10-i);
    let d1 = 11 - (sum % 11); d1 = (d1>=10)?0:d1;
    if(d1 !== parseInt(s[9])) return false;
    sum = 0;
    for(let i=0;i<10;i++) sum += parseInt(s[i])*(11-i);
    let d2 = 11 - (sum % 11); d2 = (d2>=10)?0:d2;
    return d2 === parseInt(s[10]);
  },
  required(v){ return v != null && String(v).trim().length > 0; }
};

export function validateForm(form){
  const errors = {};
  const get = id => form.querySelector('#'+id);
  const nome = get('nome')?.value || '';
  const email = get('email')?.value || '';
  const cpf = get('cpf')?.value || '';
  const telefone = get('telefone')?.value || '';
  const nascimento = get('nascimento')?.value || '';
  const endereco = get('endereco')?.value || '';
  const cep = get('cep')?.value || '';
  const cidade = get('cidade')?.value || '';
  const estado = get('estado')?.value || '';

  if(!Validators.required(nome) || nome.trim().length < 3) errors['nome'] = 'Informe seu nome (mín. 3 caracteres).';
  if(!Validators.email(email)) errors['email'] = 'E-mail inválido.';
  if(!Validators.cpf(cpf)) errors['cpf'] = 'CPF inválido.';
  if(!Validators.telefone(telefone)) errors['telefone'] = 'Telefone inválido.';
  if(!Validators.nascimento(nascimento)) errors['nascimento'] = 'Data inválida (idade mínima: 16 anos, sem datas futuras).';
  if(!Validators.required(endereco)) errors['endereco'] = 'Informe o endereço.';
  if(!Validators.cep(cep)) errors['cep'] = 'CEP inválido (00000-000).';
  if(!Validators.required(cidade)) errors['cidade'] = 'Informe a cidade.';
  if(!Validators.required(estado)) errors['estado'] = 'Selecione o estado.';

  return errors;
}

export function showErrors(form, errors){
  form.querySelectorAll('.form-error').forEach(e => e.remove());
  Object.entries(errors).forEach(([id, msg]) => {
    const input = form.querySelector('#'+id);
    if(!input) return;
    input.classList.add('is-invalid');
    const small = document.createElement('div');
    small.className = 'form-error';
    small.textContent = msg;
    input.insertAdjacentElement('afterend', small);
  });
}
